package registration;



import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Stepdef {
	
	private WebDriver webDriver;
	private WebElement webElement;
	

	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\sankekum\\Selenium\\chromedriver\\chromedriver.exe");
	 webDriver = new ChromeDriver();
	}
	@Given("^Open CapgBanking login page$")
	public void open_CapgBanking_login_page() throws Throwable {
		webDriver.get("http://localhost:8083/RamjaneBanking/");
	}

	@Given("^Click on signUp button$")
	public void click_on_signUp_button() throws Throwable {
		webElement=webDriver.findElement(By.name("lnk1"));  
		//login is the name of submit button in index.html file
		webElement.click();	
	}
	
	@Given("^provide first_name,last_name,\\.\\.etc all details$")
	public void provide_first_name_last_name_etc_all_details() throws Throwable {
		 webDriver.findElement(By.name("firstName")).sendKeys("Hari");
		 webDriver.findElement(By.name("lastName")).sendKeys("Om");
		 webDriver.findElement(By.name("dateOfbirth")).sendKeys("05/02/1995");
		 webDriver.findElement(By.name("addressline1")).sendKeys("plotno 5");
		 webDriver.findElement(By.name("addressline2")).sendKeys("MWC");
		 webDriver.findElement(By.name("city")).sendKeys("Delhi");
		 webDriver.findElement(By.name("state")).sendKeys("UP");
		 webDriver.findElement(By.name("pincode")).sendKeys("603009");
		 webDriver.findElement(By.name("email")).sendKeys("hari@gmail.com");
		 webDriver.findElement(By.name("mobile")).sendKeys("9931348262");
		 webDriver.findElement(By.name("custPwd")).sendKeys("Hari123");
		 webDriver.findElement(By.name("confirmCustPwd")).sendKeys("Hari123");
		 
		 Thread.sleep(1000);
		 webDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@When("^Register validate registration details$")
	public void register_validate_registration_details() throws Throwable {
		webElement=webDriver.findElement(By.name("register")); 
		//login is the name of submit button in index.html file
		webElement.submit();	
		
		webDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@Then("^navigate to starting login page$")
	public void navigate_to_starting_login_page() throws Throwable {
		webDriver.navigate().to("http://localhost:8083/RamjaneBanking/register");
		
	}
	@After
	public void tearDown() {
	webDriver.quit();
	}
	
}
