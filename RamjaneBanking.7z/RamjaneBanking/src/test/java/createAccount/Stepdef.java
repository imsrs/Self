package createAccount;


import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Stepdef {
	
	private WebDriver webDriver;
	private WebElement webElement;
	

	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\sankekum\\Selenium\\chromedriver\\chromedriver.exe");
	 webDriver = new ChromeDriver();
	}
	
	
	@Given("^Open CapgBanking login page$")
	public void open_CapgBanking_login_page() throws Throwable {
		  webDriver.get("http://localhost:8083/RamjaneBanking/");
	}

	@Given("^successfully loged in$")
	public void successfully_loged_in() throws Throwable {
		 webDriver.findElement(By.name("userName")).sendKeys("tom@gmail.com");
		   webDriver.findElement(By.name("userPwd")).sendKeys("tom123");
		   webElement=webDriver.findElement(By.name("login")); 
			//login is the name of submit button in index.html file
			webElement.submit();	
			
			
		
	}

	@Given("^navigate to account creation page after submit$")
	public void navigate_to_account_creation_page_after_submit() throws Throwable {
		webDriver.navigate().to("http://localhost:8083/RamjaneBanking/CreateAccountServle");
	}

	@Given("^Enter all the account details$")
	public void enter_all_the_account_details() throws Throwable {
		Select dropdown = new Select(webDriver.findElement(By.name("accountType")));
		  dropdown.selectByValue("FD"); 
		
		 webDriver.findElement(By.name("balance")).sendKeys("100000");
		 webDriver.findElement(By.name("description")).sendKeys("FD of 1 lac");
	}

	@When("^Submit create button$")
	public void submit_create_button() throws Throwable {

		 webElement=webDriver.findElement(By.name("createAcc")); 
			//login is the name of submit button in index.html file
			webElement.submit();
		
	}

	@Then("^stay at same page$")
	public void stay_at_same_page() throws Throwable {
		webDriver.navigate().to("http://localhost:8083/RamjaneBanking/CreateAccountServle");
	}
	
	@After
	public void tearDown() {
	webDriver.quit();
	}
}
