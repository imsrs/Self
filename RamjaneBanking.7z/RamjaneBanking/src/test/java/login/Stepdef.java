package login;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Stepdef {
	private WebDriver webDriver;
	private WebElement webElement;
	

	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\sankekum\\Selenium\\chromedriver\\chromedriver.exe");
	 webDriver = new ChromeDriver();
	}
	
	@Given("^Open CapgBanking login page$")
	public void open_CapgBanking_login_page() throws Throwable {
	   webDriver.get("http://localhost:8083/RamjaneBanking/");
	 //webDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@Given("^provide username and password$")
	public void provide_username_and_password() throws Throwable {
	   webDriver.findElement(By.name("userName")).sendKeys("tom@gmail.com");
	   webDriver.findElement(By.name("userPwd")).sendKeys("tom123");
	   
	 webDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@When("^Submit validate login details$")
	public void submit_validate_login_details() throws Throwable {
	  
		webElement=webDriver.findElement(By.name("login")); 
		//login is the name of submit button in index.html file
		webElement.submit();	
		webDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@Then("^navigate to MainPage$")
	public void navigate_to_MainPage() throws Throwable {
		webDriver.navigate().to("http://localhost:8083/RamjaneBanking/loginServlet");
		webDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	@After
	public void tearDown() {
	webDriver.quit();
	}

}
